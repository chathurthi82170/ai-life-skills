# agents/profiler.py

LEARNING_PROFILES = {
    "Visual & Structured Learner": {
        "focus": "Social stories, predictable routines, visual check-ins",
        "ui_hints": "Calm colors, clear distinct steps, minimal distractions.",
        "prompt_guidance": "Provide instructions as a predictable visual story. Use clear, direct language."
    },
    "Active & High-Energy Learner": {
        "focus": "Task chunking, high engagement, positive reinforcement",
        "ui_hints": "Interactive checkboxes, progress bars, gamified rewards.",
        "prompt_guidance": "Break tasks into small micro-steps. Include encouraging, high-energy positive reinforcement."
    },
    "Reading & Word Builder": {
        "focus": "Text-to-speech integration, simple sentences, reading assistance",
        "ui_hints": "Large text, heavy use of icons and visual cues.",
        "prompt_guidance": "Keep sentences short and clear. Emphasize action verbs."
    },
    "Hands-On Kinesthetic Learner": {
        "focus": "Step-by-step actions, practical practice, repetition",
        "ui_hints": "Simple layout, large interactive cards, repetitive structure.",
        "prompt_guidance": "Use foundational vocabulary. Structure as 'First do X, then do Y'."
    },
    "Auditory & Speech Learner": {
        "focus": "Voice-assisted prompts, clear text explanations",
        "ui_hints": "Rich graphical feedback, clear read-aloud buttons.",
        "prompt_guidance": "Ensure all instructions are fully descriptive in text and spoken prompts."
    },
    "Gentle Pace Learner": {
        "focus": "High contrast, step-by-step guidance",
        "ui_hints": "High contrast mode, large bold fonts.",
        "prompt_guidance": "Provide rich descriptive text. Break down spatial steps clearly."
    }
}

# Alias for backwards compatibility
DISABILITY_PROFILES = LEARNING_PROFILES

class ProfilerAgent:
    def __init__(self, disability_type: str):
        self.disability_type = disability_type
        self.profile = LEARNING_PROFILES.get(disability_type, {})
        
    def get_system_prompt_addition(self) -> str:
        """Returns the specific guidance for the LLM based on the child's learning profile."""
        if not self.profile:
            return "Adapt the instructions to be as clear and engaging as possible for children."
            
        guidance = (
            f"The user is a child with a {self.disability_type} learning preference. "
            f"Focus: {self.profile['focus']}. "
            f"Instruction Style: {self.profile['prompt_guidance']}"
        )
        return guidance
        
    def get_ui_hints(self) -> str:
        return self.profile.get("ui_hints", "Standard UI")
