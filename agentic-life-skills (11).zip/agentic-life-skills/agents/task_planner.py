# agents/task_planner.py
import os
import json
import requests
import urllib.parse
import re
from openai import OpenAI

# Rich, detailed fallback skill library for common life skills
SKILL_LIBRARY = {
    "brush": {
        "title": "Brushing Your Teeth",
        "steps": [
            "🦷 Go to the bathroom sink and turn on the tap with cool water.",
            "💧 Wet your toothbrush under the running water for 3 seconds.",
            "🪥 Put a small pea-sized amount of toothpaste on the bristles. Not too much!",
            "👄 Put the toothbrush gently in your mouth. Close your lips around it.",
            "⭕ Move the brush in small circles on the OUTSIDE of your top teeth for 20 seconds.",
            "⭕ Move the brush in small circles on the OUTSIDE of your bottom teeth for 20 seconds.",
            "🔄 Now brush the INSIDE of your top teeth (the side facing your tongue) for 20 seconds.",
            "🔄 Brush the INSIDE of your bottom teeth for 20 seconds.",
            "➡️ Brush the flat BITING surfaces of your top teeth back and forth.",
            "➡️ Brush the flat BITING surfaces of your bottom teeth back and forth.",
            "👅 Gently brush your tongue once or twice to remove bacteria.",
            "🚰 Spit out the toothpaste foam into the sink. Do NOT swallow it.",
            "💧 Rinse your mouth with a small sip of clean water and spit it out.",
            "🚿 Rinse your toothbrush under running water and shake off the extra water.",
            "🗂️ Put your toothbrush back in its holder with the bristles facing UP to dry.",
            "✅ Turn off the tap. Great job! Your teeth are clean and healthy! 🌟"
        ]
    },
    "wash hands": {
        "title": "Washing Your Hands",
        "steps": [
            "🚰 Walk to the nearest sink.",
            "🙌 Turn on the tap. Use warm water, not too hot.",
            "💧 Place both hands under the water and get them completely wet.",
            "🚿 Turn off the tap (to save water while you wash).",
            "🧴 Pick up the soap. Pump the liquid soap once onto your palm, or rub the bar soap.",
            "🤲 Rub your palms together to make a lather (bubbly foam).",
            "🔄 Rub the back of your left hand using your right palm. Do this 5 times.",
            "🔄 Now rub the back of your right hand using your left palm. Do this 5 times.",
            "🤞 Interlace your fingers and rub between them to clean the gaps.",
            "👍 Rub your right thumb in a circle using your left fist. Switch and do the other thumb.",
            "⏱️ Scrub your hands for at least 20 seconds (try humming 'Happy Birthday' twice!).",
            "🚰 Turn the tap back on and rinse all the soap off thoroughly.",
            "🏷️ Make sure no slippery soap is left on your hands.",
            "🧻 Dry your hands completely with a clean towel or paper towel.",
            "🗑️ If you used a paper towel, throw it in the bin.",
            "✅ You are done! Clean hands keep you and others healthy! 🌟"
        ]
    },
    "sandwich": {
        "title": "Making a Sandwich",
        "steps": [
            "🙌 First, wash your hands with soap and water for 20 seconds.",
            "🍞 Get two slices of bread from the bag and place them on a clean plate.",
            "🔪 Get a butter knife from the kitchen drawer. Remember — be careful with sharp edges!",
            "🧈 Open the butter or spread. Use the knife to scoop a small amount.",
            "🍞 Spread the butter or spread evenly on ONE side of one slice of bread.",
            "🥪 Place your chosen filling in the centre of the buttered slice (e.g., cheese, jam, or tuna).",
            "🥗 If you want, add some lettuce or tomato slices on top of the filling.",
            "🍞 Place the second slice of bread on top with the plain side facing UP.",
            "✂️ If you like, gently cut the sandwich diagonally from corner to corner.",
            "🧹 Put the knife in the sink for washing. Close all food containers and put them away.",
            "🗑️ Wipe the plate and counter with a clean cloth.",
            "✅ Your sandwich is ready to eat! Enjoy your meal! 🌟"
        ]
    },
    "morning routine": {
        "title": "Morning Routine",
        "steps": [
            "⏰ When your alarm rings, sit up in bed slowly. Take 3 deep breaths.",
            "🛏️ Fold your blanket neatly and straighten your pillow.",
            "🚰 Go to the bathroom and splash cold water on your face to wake up.",
            "🪥 Brush your teeth for 2 full minutes.",
            "🚿 Take a shower or bath. Use soap on your body and shampoo on your hair.",
            "🧴 Dry yourself completely with a towel, including between your toes.",
            "👕 Go to your room and pick out your clothes for the day.",
            "👗 Put on your underwear first, then your clothes, then your socks, then your shoes.",
            "💈 Comb or brush your hair neatly.",
            "🍳 Go to the kitchen for breakfast. Eat a healthy meal.",
            "💊 Take any medicines if needed (ask an adult to help you).",
            "🎒 Pack your school bag — check for books, lunch box, and water bottle.",
            "✅ You are ready to have a wonderful day! 🌟"
        ]
    },
    "road crossing": {
        "title": "Crossing a Road Safely",
        "steps": [
            "⛔ STOP at the edge of the footpath (pavement). Never step on the road yet.",
            "👀 LOOK for a zebra crossing, traffic light, or a safe crossing point nearby.",
            "🚦 If there is a traffic light, wait for the GREEN pedestrian signal (the walking person icon).",
            "👂 LISTEN carefully — turn off any music and remove earphones.",
            "👈 Look to the LEFT first to check for vehicles coming from that direction.",
            "👉 Look to the RIGHT to check for vehicles coming from that side.",
            "👈 Look to the LEFT one more time (Left → Right → Left is the safe rule!).",
            "🚗 If any vehicle is coming, WAIT patiently until the road is completely clear.",
            "🚶 When the road is clear and the light is GREEN, start walking quickly but calmly.",
            "➡️ Walk in a STRAIGHT LINE directly across the road. Do not run or stop in the middle.",
            "👀 Keep watching for vehicles as you cross — stay alert!",
            "✅ Reach the other side safely. Well done! Always cross at safe points! 🌟"
        ]
    },
    "washing clothes": {
        "title": "Washing Clothes",
        "steps": [
            "👕 Collect your dirty clothes and bring them to the washing area.",
            "🔍 Check the label on each garment for washing instructions.",
            "🗂️ Sort clothes into groups: light colours together, dark colours together.",
            "🔲 Open the washing machine door and place the clothes inside.",
            "🚫 Do not overfill — clothes need space to tumble and clean properly.",
            "🧴 Measure the correct amount of laundry detergent using the cap.",
            "🫙 Pour the detergent into the drawer labelled 'Main Wash'.",
            "🌡️ Select the right temperature (usually 30°C for colours, 40°C for whites).",
            "▶️ Close the door firmly and press the Start button.",
            "⏳ Wait for the machine to complete its cycle (usually 30–60 minutes).",
            "🔔 When the machine beeps, open the door and take the clothes out promptly.",
            "🪢 Shake each item of clothing to reduce wrinkles.",
            "🏳️ Hang the clothes on a drying rack or clothesline in a well-ventilated area.",
            "☀️ Leave them to dry completely. Check after a few hours.",
            "✅ Once dry, fold them neatly and put them away in the right place! 🌟"
        ]
    },
    "cook rice": {
        "title": "Cooking Rice",
        "steps": [
            "🧑‍🍳 Ask an adult to supervise as the stove can be very hot.",
            "🍚 Measure 1 cup of dry rice using a measuring cup.",
            "🚰 Pour the rice into a bowl. Fill with cold water and use your hand to swirl.",
            "💧 Drain the cloudy water carefully. Repeat this rinsing 2–3 times until water is clearer.",
            "🍲 Pour the rinsed rice into a medium saucepan.",
            "💧 Add 2 cups of cold water to the pot (the ratio is 1 part rice to 2 parts water).",
            "🧂 Add a tiny pinch of salt if you like.",
            "🔥 Place the pot on the stove on HIGH heat. Watch it carefully.",
            "⏳ Wait for the water to reach a full, bubbling boil.",
            "📉 As soon as it boils, turn the heat down to the LOWEST setting.",
            "🫙 Put the lid on the pot tightly.",
            "⏱️ Let the rice cook on LOW heat for exactly 18 minutes. Do NOT lift the lid.",
            "🔕 After 18 minutes, turn the stove OFF. Keep the lid on for 5 more minutes.",
            "🍴 Open the lid carefully (steam is very hot!). Fluff the rice gently with a fork.",
            "✅ Your rice is cooked! Serve with your favourite dish. Well done! 🌟"
        ]
    }
}

def find_best_skill(task_name):
    """Find the best matching skill from the library."""
    task_lower = task_name.lower()
    for key, skill in SKILL_LIBRARY.items():
        if key in task_lower or any(word in task_lower for word in key.split()):
            return skill
    return None


class TaskPlannerAgent:
    def __init__(self, profiler):
        self.profiler = profiler
        self.api_key = os.environ.get("OPENAI_API_KEY")
        self.client = None
        if self.api_key and "your_actual_openai_key" not in self.api_key and len(self.api_key) > 20:
            try:
                self.client = OpenAI(api_key=self.api_key)
            except Exception:
                self.client = None

    def generate_mcq(self, task_name: str) -> list:
        """Generates a multiple-choice question to test prior knowledge of the task."""
        if self.client:
            try:
                system_prompt = (
                    f"You are a helpful AI Coach. The user is a child with a {self.profiler.disability_type} learning style. "
                    "Generate one simple multiple-choice question to test their understanding of the task before they do it. "
                    "Return ONLY JSON in this format: [{\"question\": \"...\", \"options\": [\"A\", \"B\", \"C\"], \"answer\": \"Correct Option\"}]"
                )
                response = self.client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": f"Task: {task_name}"}
                    ],
                    temperature=0.7,
                )
                content = response.choices[0].message.content
                if content.startswith("```json"):
                    content = content[7:-3]
                return json.loads(content)
            except Exception:
                pass
                
        # Free Live AI API
        return self._free_ai_mcq(task_name)

    def _free_ai_mcq(self, task_name: str) -> list:
        """Generate live AI MCQ using Free Pollinations AI API."""
        try:
            prompt = (
                f"Generate 1 simple multiple-choice question for a child about '{task_name}'. "
                'Return ONLY a JSON array in this exact format: [{"question": "...", "options": ["Option A", "Option B", "Option C"], "answer": "Option A"}]'
            )
            url = f"https://text.pollinations.ai/{urllib.parse.quote(prompt)}"
            resp = requests.get(url, timeout=10)
            if resp.status_code == 200:
                text = resp.text.strip()
                if "```" in text:
                    text = re.sub(r'```json\s*|```\s*', '', text).strip()
                data = json.loads(text)
                if isinstance(data, list) and len(data) > 0:
                    return data
        except Exception:
            pass
        return self._mock_mcq(task_name)

    def _mock_mcq(self, task_name: str) -> list:
        """Rich mock MCQ generator based on skill."""
        skill = find_best_skill(task_name)
        if skill:
            qs = {
                "Brushing Your Teeth": {"question": "How long should you brush your teeth for?", "options": ["10 seconds", "At least 2 minutes", "5 minutes"], "answer": "At least 2 minutes"},
                "Washing Your Hands": {"question": "How long should you scrub your hands with soap?", "options": ["3 seconds", "At least 20 seconds", "5 minutes"], "answer": "At least 20 seconds"},
                "Making a Sandwich": {"question": "What is the FIRST thing you should do before making food?", "options": ["Get the bread", "Wash your hands", "Open the fridge"], "answer": "Wash your hands"},
                "Morning Routine": {"question": "In a morning routine, what should you do BEFORE getting dressed?", "options": ["Pack your bag", "Shower and brush teeth", "Eat breakfast"], "answer": "Shower and brush teeth"},
                "Crossing a Road Safely": {"question": "Before crossing a road, which direction should you look FIRST?", "options": ["Right", "Left", "Up"], "answer": "Left"},
            }
            q = qs.get(skill["title"], None)
            if q:
                return [q]
        return [{"question": f"Before we start {task_name}, what is the most important thing to remember?", "options": ["Taking our time and being safe", "Rushing to finish fast", "Asking someone else to do it"], "answer": "Taking our time and being safe"}]

    def plan_task(self, task_name: str) -> list:
        """Generates a step-by-step breakdown of a task tailored to the user profile."""
        if self.client:
            try:
                system_prompt = (
                    "You are an expert AI Life Skills Coach for children learning essential daily life skills. "
                    "Your goal is to break down daily tasks into clear, manageable steps. "
                    f"{self.profiler.get_system_prompt_addition()}\n"
                    "Return the response ONLY as a JSON array of strings, where each string is a step."
                )
                user_prompt = f"Break down this task into steps: '{task_name}'"
                response = self.client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=0.7,
                )
                content = response.choices[0].message.content
                if content.startswith("```json"):
                    content = content[7:-3]
                steps = json.loads(content)
                if isinstance(steps, list):
                    return steps
            except Exception:
                pass
                
        # Call Free Live AI API
        return self._free_ai_plan(task_name)

    def _free_ai_plan(self, task_name: str) -> list:
        """Call Free Pollinations AI API to dynamically generate live AI step breakdown for ANY skill."""
        try:
            prompt = (
                f"Break down the life skill '{task_name}' for a child with a {self.profiler.disability_type} learning style into 6 clear, encouraging step-by-step instructions with emojis. "
                "Return ONLY a JSON array of 6 strings."
            )
            url = f"https://text.pollinations.ai/{urllib.parse.quote(prompt)}"
            resp = requests.get(url, timeout=12)
            if resp.status_code == 200:
                text = resp.text.strip()
                if "```" in text:
                    text = re.sub(r'```json\s*|```\s*', '', text).strip()
                steps = json.loads(text)
                if isinstance(steps, list) and len(steps) >= 3:
                    return steps
        except Exception:
            pass
        return self._mock_plan(task_name)

    def _mock_plan(self, task_name: str) -> list:
        """Fallback plan that uses the detailed skill library."""
        skill = find_best_skill(task_name)
        if skill:
            return skill["steps"]
        
        profile_type = self.profiler.disability_type

        return [
            f"📋 Today's task: **{task_name}**. Let's get started!",
            "🛠️ Step 1: Collect all the items or materials you will need.",
            "👀 Step 2: Look at the task and understand what the end result should look like.",
            "▶️ Step 3: Begin the task carefully and at a comfortable pace.",
            "🔄 Step 4: Continue each part of the task in the correct order.",
            "🧐 Step 5: Check your progress halfway through.",
            "🏁 Step 6: Complete the final part of the task.",
            "🧹 Step 7: Clean up and put everything away neatly.",
            "✅ You finished! Great work completing **{task_name}** today! 🌟".format(task_name=task_name)
        ]
